class User {
  String? id;
  String? name;
  String? email;
  String? password;
  String? usertype;
  String? gender;
  String? image;
  String? status;

  User({
    this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.usertype,
    required this.gender,
    required this.image,
    this.status = 'active',
  });

  factory User.fromJson(Map<String, dynamic> json) {
    final userJson = json['user'] ?? json;
    return User(
      id: userJson['_id'],
      name: userJson['name'],
      email: userJson['email'],
      password: userJson['password'],
      usertype: userJson['usertype'],
      gender: userJson['gender'],
      image: userJson['image'],
      status: userJson['status'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'name': name,
      'email': email,
      'password': password,
      'usertype': usertype,
      'gender': gender,
      'image': image,
      'status': status,
    };
  }
}
