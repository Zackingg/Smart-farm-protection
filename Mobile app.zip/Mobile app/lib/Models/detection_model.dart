// models/detection_model.dart

class DetectionModel {
  final String id;
  final String label;
  final String message;
  final String image;
  final DateTime timestamp;

  DetectionModel({
    required this.id,
    required this.label,
    required this.message,
    required this.image,
    required this.timestamp,
  });

  factory DetectionModel.fromJson(Map<String, dynamic> json) {
    return DetectionModel(
      id: json['_id'],
      label: json['label'],
      message: json['message'],
      image: json['image'],
      timestamp: DateTime.parse(json['timestamp']),
    );
  }
}
