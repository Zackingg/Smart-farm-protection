// providers/detection_provider.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/detection_model.dart';

class DetectionProvider with ChangeNotifier {
  List<DetectionModel> _detections = [];
  bool _isLoading = false;

  List<DetectionModel> get detections => _detections;
  bool get isLoading => _isLoading;

  Future<void> fetchDetections() async {
    _isLoading = true;
    notifyListeners();

    final url = Uri.parse('https://firm-detection-api.onrender.com/alert/');

    try {
      final response = await http.get(url);
      final data = json.decode(response.body);

      if (response.statusCode == 200) {
        final List<dynamic> detectionsJson = data['data'];
        _detections = detectionsJson.map((json) => DetectionModel.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load detections');
      }
    } catch (error) {
      print(error);
    }

    _isLoading = false;
    notifyListeners();
  }
}
